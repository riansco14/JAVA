
package net.phbwt.jtans;

import net.phbwt.jtans.guicommon.*;
import net.phbwt.jtans.guimain.DisplayFigureComponent;

import java.io.*;
import java.util.Locale;
import java.util.Observable;
import java.util.zip.*;


public class jTansApplication extends AbstractApplication {
    
    private static final String CONFIG_NAME = ".jTans.config.gz";
    public static boolean Gerson=false;


    public static void main(String[] args){
    	
	jTansApplication jt = new jTansApplication();
	jt.start();
	
	while (!Gerson) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	JOGOGERSON.Gerson.markin=true;
    }
    

    protected Config retrieveConfig() {
	
	Config ret;

	try {

	    ObjectInputStream ois = new ObjectInputStream(new GZIPInputStream(new BufferedInputStream(new FileInputStream(System.getProperty("user.home") + "/" + CONFIG_NAME))));
	    ret = (Config) ois.readObject();
	    ois.close();
	} catch (Exception e) {
	    System.err.println("*INFO*:can't find/load preferences");
	    e.printStackTrace(System.err);
	    ret = new Config();
	}

	return ret;
    }


    protected void saveConfig(Config cf) {

	try {
	    
	    ObjectOutputStream oos = new ObjectOutputStream(new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.home") + "/" + CONFIG_NAME))));
	    
	    oos.writeObject(config);
	    
	    oos.close();
	    
	} catch (Exception ex) {
	    System.err.println("*INFO*: Can't save config:");
	    ex.printStackTrace(System.err);
	} 
    }


	@Override
	public void update(Observable o, Object arg) {
		
	}
}    

