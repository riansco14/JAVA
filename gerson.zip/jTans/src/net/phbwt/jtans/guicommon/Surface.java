
package net.phbwt.jtans.guicommon;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;
import java.net.*;
import javax.swing.*;


/**
 * Remplissage d'une surface (couleur ou texture). 
 * Encapsule un Paint et les param�tres permettant de l'obtenir.
 */

public class Surface implements Serializable, Config.ConfigItem {

    static final long serialVersionUID = 1;

    // nom de base des ressources texture 
    private static final String BASE_TEXTURE_PATH = "net/phbwt/jtans/images";

    public static final int COLOR = 1;
    public static final int USER_TEXTURE = 2;
    public static final int BASE_TEXTURE = 3;

    private int type;  // COLOR, BASE_TEXTURE ou USER_TEXTURE

    private Color color;            // pour le type COLOR
    private File textureFile;       // pour le type USER_TEXTURE
    private String baseTextureName; // pour le type BASE_TEXTURE
    private float brightness;       // pour les types USER_TEXTURE et BASE_TEXTURE

    private transient Paint paint = null; // objet paint correspondant au type

    private transient BufferedImageOp brightOp = null; // Op�rateur �claircissant/assombrissant la texture

    private static String[] baseTextures = null;  // liste des textures de type BASE_TEXTURE


    Surface() {}


    Surface(int t, Color col, String base, String fileName, float brightness) {
	type = t;
	color = col;
	textureFile = (fileName == null) ? null : new File(fileName);
	baseTextureName = base;
	this.brightness = brightness;
    }


    /**
     * Get the value of brightness.
     * @return value of brightness.
     */

    public float getBrightness() {
	return brightness;
    }
    

    /**
     * Set the value of brightness.
     * @param v  Value to assign to brightness.
     */

    public void setBrightness(float  v) {
	this.brightness = v;
	paint = null;
	brightOp = null;
    }
    

    /**
     * Get the value of type.
     * @return value of type.
     */

    public int getType() {
	return type;
    }
    

    /**
     * Set the value of type.
     * @param v  Value to assign to type.
     */

    public void setType(int  v) {
	this.type = v;
	paint = null;
    }
    

    /**
     * Get the value of color.
     * @return value of color.
     */

    public Color getColor() {
	return color;
    }
    

    /**
     * Set the value of color.
     * @param v  Value to assign to color.
     */

    public void setColor(Color  v) {
	this.color = v;
	paint = null;
    }
    

    /**
     * Get the value of textureFile.
     * @return value of textureFile.
     */

    public File getTextureFile() {
	return textureFile;
    }
    

    /**
     * Set the value of textureFile.
     * @param v  Value to assign to textureFile.
     */

    public void setTextureFile(File  v) {
	this.textureFile = v;
	paint = null;
    }
    

    /**
     * Get the value of baseTextureName.
     * @return value of baseTextureName.
     */

    public String getBaseTextureName() {
	return baseTextureName;
    }

    
    /**
     * Set the value of baseTextureName.
     * @param v  Value to assign to baseTextureName.
     */

    public void setBaseTextureName(String  v) {
	this.baseTextureName = v;
	paint = null;
    }
    

    /**
     * Cherche la liste des textures de base.
     * La liste est construite au premier appel � partir
     * du fichier texte 'textureList.txt' plac� avec les classes.
     *
     * @return la liste sous forme de tableau �ventuellement de taille 0
     *         (entre autre si le fichier n'existe pas).
     */

    public static String[] getBaseTextures() {
	
	if ( baseTextures == null ) {
	    
	    Collection coll = new TreeSet();

	    try {
//  		String resourceName = Surface.class.getPackage().getName().replace('.', '/') +
//  		    "/images/baseTextures.txt";

		String resourceName = BASE_TEXTURE_PATH + "/baseTextures.txt";

		for ( Enumeration e = Surface.class.getClassLoader().getResources(resourceName);
		      e.hasMoreElements(); ) {
		    
//  		    String res = e.nextElement().toString();
//  		    System.out.println("res=" + res);

		    InputStream is = ((URL)e.nextElement()).openStream();
		    if ( is != null ) {
			BufferedReader in = new BufferedReader(new InputStreamReader(is));
			
			String s;
			while ( (s = in.readLine()) != null ) {
			    s = s.trim();
			    if ( !"".equals(s) ) {
				coll.add(s);
			    }
			} 
			
			in.close();
		    }
		} 
	    } catch (IOException e) {
		e.printStackTrace(System.err);
	    }

	    baseTextures =(String[])coll.toArray(new String[0]);
	} 
	
	return baseTextures;
    }


    /**
     * Renvoi le Paint correspondant.
     * Apr�s l'avoir instanci� si n�cessaire.
     *
     * @return un Paint.
     *
     * @throws Exception vari�es si une texture n'est pas trouv�e.
     */

    public Paint getPaint(JComponent comp) throws Exception {

	if ( paint == null ) {

	    switch ( type ) {
	    case COLOR:
		if ( color != null ) {
		    paint = color;
		}
		break;
		
	    case USER_TEXTURE:
		if ( textureFile != null ) {
		    paint = loadTexture(textureFile.toURL(), comp);
		} else {
		    throw new RuntimeException( "pas de nom de fichier pour la texture");
		} 
		
		break;
		
	    case BASE_TEXTURE:
		if (baseTextureName != null ) {
		    URL url = Surface.class.getResource("/" + BASE_TEXTURE_PATH + "/" + baseTextureName);
		    if ( url == null ) {
			throw new RuntimeException( "pas trouve la texture de base : " +
						    baseTextureName );
		    } 
		    paint = loadTexture(url, comp);
		} else {
		    throw new RuntimeException( "pas de nom de texture de base");
		}
		break;
	    }
	} 

	return paint;
    }


    /**
     * M�thode utilitaire : r�cup�re le paint, ou une valeur par d�faut. 
     *
     * @return un Paint, Color.black en cas de probl�me.
     */

    public Paint getPaintNoError(JComponent comp) {

	Paint ret;

	try {
	    
	    ret = getPaint(comp);
		
	} catch (Exception  e) {
	    System.err.println("*INFO*: pas trouve le paint");
	    e.printStackTrace(System.err);
	    ret = Color.black;
	}
	
	return ret;
    }

    /**
     * Charge une texture.
     *
     * @param comp le composant pour lequel la texture doit �tre cr�e.
     */

    private TexturePaint loadTexture(URL nom, JComponent comp) {

	if ( Math.abs(brightness - 1f) > 1E-3  && brightOp == null ) {
	    brightOp = new RescaleOp(brightness, 0, null);
	} 

	Image im = new ImageIcon(nom).getImage();

	int w = im.getWidth(comp);
	int h = im.getHeight(comp);
	BufferedImage bi = (BufferedImage)comp.createImage(w, h);

	Graphics2D gr = bi.createGraphics();
	gr.drawImage(im, 0, 0, comp);

//  	System.out.println("op=" + brightOp);
	if ( brightOp != null) {
	    brightOp.filter(bi, bi);
//  	    System.out.println("op=" + brightOp +
//  			       " br=" + ((RescaleOp)brightOp).getScaleFactors(null)[0]);
	} 

	gr.dispose();

	Rectangle re = new Rectangle(0, 0, w, h); 
	return new TexturePaint(bi, re);
    }


    /**
     *
     */

    public String toString() {

	return "Surface:type=" + type +
	    ":color=" + color +
	    ":base=" + baseTextureName +
	    ":file=" + textureFile +
	    ":bright=" + brightness;
    }


    /**
     * test.
     */

    public static void main (String[] args) {
	try {
	    String[] strs = getBaseTextures();

	    System.err.println("*****");

	    for ( int i = 0; i < strs.length; i++) {
		System.out.println(strs[i]);
	    }

	    System.err.println("*****");
	     
	} catch (Exception e) {
	    e.printStackTrace();
	} 
    } 

    public Object clone() throws CloneNotSupportedException {
	return super.clone();
    }
} 

