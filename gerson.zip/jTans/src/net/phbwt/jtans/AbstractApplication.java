
package net.phbwt.jtans;

import net.phbwt.jtans.guimain.*;
import net.phbwt.jtans.guicommon.*;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;

/*
 * Superclasse des applications (standard ou webstart).
 * Reste � implementer la r�cup�ration/sauvegarde de la config.
 * et le main.
 * Observe MainWindow : "jtans.help" et "jtans.about".
 */

public abstract class AbstractApplication implements Observer {
    
    protected MainWindow mainWindow;
    
    protected Config config;

    protected static ResourceBundle i18n = null;


    protected AbstractApplication() {

	if ( i18n == null ) {
	    i18n = ResourceBundle.getBundle("net.phbwt.jtans.i18n.main");
	} 
    }


    protected void start(){
	
	//
	// la config
	//

	config = retrieveConfig();


	//
	// les fen�tres
	//

	mainWindow = new MainWindow(config);

	JFrame mainWinFrame = new JFrame("jTans");
	mainWinFrame.addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
//  		    System.out.println("main closing");
		    quit();
		}
//  		public void windowClosed(WindowEvent e) {
//  		    System.out.println("main closed");
//  		    quit();
//  		}
	    });
	
	mainWindow.fill(mainWinFrame);


	//
	// les menus : le premier (config, quit) est cr��, les autres sont demand�s � MainWindow.
	//

	JMenu firstMenu = new JMenu(i18n.getString("menu.game"));
	firstMenu.add(i18n.getString("menu.game.configure")).addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		}
	    });
	firstMenu.add(i18n.getString("menu.game.quit")).addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    quit();
		}
	    });
	
	JMenuBar menuBar = new JMenuBar();
	menuBar.add(firstMenu);
	for ( Iterator i = mainWindow.getMenus().iterator(); i.hasNext(); ) {
	    menuBar.add((JMenu) i.next());
	}
	
	mainWindow.addObserver(this);


	/* fin */

	mainWinFrame.setJMenuBar(menuBar);
	mainWinFrame.pack();
	mainWinFrame.setSize(mainWinFrame.getPreferredSize());  // ???
	mainWinFrame.show();
    }

    
    private void quit() {
	

	saveConfig(config);
	
//  	try {
//  	    Thread.sleep(60000);
//  	} catch (InterruptedException e) {	} 

	System.exit(0);
    }


    /**
     * Gestion des evenement venants de MainWindow.
     */

  


    protected abstract Config retrieveConfig();
    protected abstract void saveConfig(Config cf);
}    

