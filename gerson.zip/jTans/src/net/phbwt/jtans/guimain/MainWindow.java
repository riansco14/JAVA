
package net.phbwt.jtans.guimain;

import net.phbwt.jtans.jTansApplication;
import net.phbwt.jtans.guicommon.*;
import net.phbwt.jtans.calc.*;

import java.awt.*;
// import java.awt.Container;
// import java.awt.Dimension;
// import java.awt.Insets;
// import java.awt.GridBagLayout;
// import java.awt.GridBagConstraints;
// import java.awt.Window;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

import java.util.*;
import java.util.List;
import java.beans.*;
import java.lang.reflect.*;


/**
 * Controller de la fen�tre principale.
 * Observateur de la config.
 * Observable : emet "jtans.help" et "jtans.about".
 */

public class MainWindow extends Observable implements Observer {
    
    private static final boolean DEBUG = false;
    private static final int BUTTON_GAP = 5;

    private EditableFigureComponent grandeArea;
    private DisplayFigureComponent petiteArea;
    private StatusBar statusBar;

    // uniquement pour init, reconfig ou pour savoir si une figure est trouv�e
    private Config config;

    // setMax sur le model du spinner ou le slider
    private Method setMaxMethod;  // methode du spinner ou null
    private Method setValMethod;  // methode du spinner ou null
    private Object setValMaxObject;  // spinnermodel ou slider

    // liste et figure en cours (�ventuellement diff�rente du contenu actuel de la config)
    private List actualList;
    private String actualName; 
    private int actualFigNr;

    private static ResourceBundle i18n = null;


    public MainWindow(Config cf) {

	if ( i18n == null ) {
	    i18n = ResourceBundle.getBundle("net.phbwt.jtans.i18n.main");
	} 
	
	config = cf;

	config.addObserver(this);
	
	FigureGroup fli = cf.getFigureGroup("main.figureList");

	actualList = fli.getListNoError();
	actualName = fli.getName();
	actualFigNr = 0;
    }


    public void fill(RootPaneContainer rootContainer) {

	CalcFigure cFigD = ((CalcFigure.StoredFigure) actualList.get(actualFigNr)).getCalcFigure();
	CalcFigure cFigE = new CalcFigure();

	//
	// composants figures 
	//

	EditableFigure eFigE = new EditableFigure(cFigE);
	DisplayFigure dFigE = new DisplayFigure(cFigD);
	DisplayFigure dFigD = new DisplayFigure(cFigD);

	petiteArea = new DisplayFigureComponent( dFigD,
						 config,
						 config.isSolved(actualName, actualFigNr) );
	petiteArea.setPreferredSize(new Dimension(140, 140));
	petiteArea.setMinimumSize(petiteArea.getPreferredSize());
	petiteArea.setBorder(BorderFactory.createEtchedBorder());
//  	petiteArea.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED)); // since 1.3
//    	petiteArea.setBorder(new MatteBorder(10, 10, 50, 50, Color.blue));
	
	JPanel petiteCont = new JPanel(new LayoutCarre());
	petiteCont.add(petiteArea);
	
	grandeArea = new EditableFigureComponent(eFigE, dFigE, config);
	grandeArea.setPreferredSize(new Dimension(420, 420));
	grandeArea.setMinimumSize(grandeArea.getPreferredSize());
	grandeArea.setBorder(BorderFactory.createEtchedBorder());
//  	grandeArea.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED)); // since 1.3
//    	grandeArea.setBorder(new MatteBorder(1, 1, 100, 100, Color.red));
  	grandeArea.addPropertyChangeListener(new PropertyChangeListener() {

  		public void propertyChange(java.beans.PropertyChangeEvent evt) {

		    if (DEBUG) {
			System.out.println("propchange:" + evt.getPropertyName() + "=" + evt.getNewValue());
		    } 

		    if (EditableFigureComponent.PROPERTY_FOUND.equals(evt.getPropertyName())) {
			if (Boolean.TRUE.equals(evt.getNewValue())) {
			    petiteArea.setSolved(true);
			    config.setSolved(actualName, actualFigNr, true);
			    statusBar.setMessage(3, i18n.getString("statusBar.wellDone"));
			    jTansApplication.Gerson=true;
			} else {
			    statusBar.setMessage(3, null);
			}
		    } else if (EditableFigureComponent.PROPERTY_SELECTION.equals(evt.getPropertyName())) {
			statusBar.setMessage(2, Boolean.TRUE.equals(evt.getNewValue()) ?
					     i18n.getString("statusBar.selected") :
					     null);
		    }
  		}
	    });
	
	JPanel grandeCont = new JPanel(new LayoutCarre());
	grandeCont.add(grandeArea);
	
	
	//
	//  groupe de boutons
	//

	Container figNrComp = figNrInit(actualList.size());

	JButton unselButton = new JButton();
	unselButton.setText(i18n.getString("button.unselect"));
	unselButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

  		    grandeArea.unselect();

//  		    if ( (e.getModifiers() & ActionEvent.SHIFT_MASK) != 0 ) {
//  			// affiche la figure 
//  			System.out.println(grandeArea.fig.getCalcFigure().getStoredFigure().toString());
//  		    } // end of if ()
		}
	    });
	
	JButton flipButton = new JButton();
	flipButton.setText(i18n.getString("button.flip"));
	flipButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
  		    grandeArea.flip();
		}
	    });
	
	JPanel pieceBox = new JPanel(new GridLayout(2, 1, 0, BUTTON_GAP));
	pieceBox.setBorder(BorderFactory.
			   createTitledBorder(BorderFactory.createEtchedBorder(),
					      i18n.getString("boxtitle.piece")));
	pieceBox.add(flipButton);
	pieceBox.add(unselButton);

	JButton showTanButton = new JButton();
	showTanButton.setText(i18n.getString("button.showTan"));
	showTanButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
  		    petiteArea.selectNext();
  		    petiteArea.repaint();
		}
	    });
	
	JButton showOutButton = new JButton();
	showOutButton.setText(i18n.getString("button.showOutline"));
	showOutButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
  		    grandeArea.toggleOutline();
		}
	    });

	JPanel helpBox = new JPanel(new GridLayout(2, 1, 0, BUTTON_GAP));
	helpBox.setBorder(BorderFactory.
			  createTitledBorder(BorderFactory.createEtchedBorder(),
					     i18n.getString("boxtitle.help")));
	helpBox.add(showTanButton);
	helpBox.add(showOutButton);

	
	JPanel buttonBox = new JPanel(new GridBagLayout());
	GridBagConstraints gbc2 = new GridBagConstraints();
	gbc2.gridx = 0;
	gbc2.gridy = GridBagConstraints.RELATIVE;
	gbc2.gridwidth = 1;
	gbc2.gridheight = 1;
	gbc2.fill =  GridBagConstraints.HORIZONTAL;
	gbc2.weightx = 1;
	gbc2.weighty = 0;
	gbc2.insets = new Insets(0, 0, BUTTON_GAP, 0);

	buttonBox.add(figNrComp, gbc2);
// 	buttonBox.add(unselButton, gbc2);
// 	buttonBox.add(flipButton, gbc2);
 	buttonBox.add(pieceBox, gbc2);
// 	buttonBox.add(showTanButton, gbc2);
// 	buttonBox.add(showOutButton, gbc2);
 	buttonBox.add(helpBox, gbc2);
	Dimension dum = new Dimension(0, 0);
	gbc2.weighty = 1;
	buttonBox.add(new Box.Filler(dum, dum, new Dimension(0, Short.MAX_VALUE)), gbc2);

	// pour �viter de perturber les proportions 
	Dimension d = buttonBox.getPreferredSize();
	d.width = 50;  // le gridbaglayout en donnera plus
	buttonBox.setPreferredSize(d);


	//
	// status bar
	//

	statusBar = new StatusBar(5);
	statusBar.setBorder(BorderFactory.createEtchedBorder());
	statusBar.setMessage(1, i18n.getString("statusBar.unSelected"));
	statusBar.setVisible(config.getBoolean("main.showStatus", true));


//  	Box buttonBox = Box.createVerticalBox();
//  	buttonBox.setBorder(BorderFactory.createLineBorder(java.awt.Color.blue));
//  	buttonBox.add(figNrComp);
//  	buttonBox.add(unselButton);
//  	buttonBox.add(flipButton);
//  	buttonBox.add(showTanButton);
//  	buttonBox.add(showOutButton);
//  	Dimension dum = buttonBox.getMinimumSize();
//  	dum.height = (dum.height <= 280) ? 280 - dum.height : 0;
//  	dum.width = 0;
//  	buttonBox.add(new Box.Filler(dum, dum, new Dimension(0, Short.MAX_VALUE)));
	

	//
	// placement dans la "fen�tre" re�ue
	//
	
	rootContainer.getContentPane().setLayout(new GridBagLayout());

	Container cont = rootContainer.getContentPane();
	GridBagConstraints gbc = new GridBagConstraints();

	gbc.anchor =  GridBagConstraints.CENTER;
	gbc.fill =  GridBagConstraints.BOTH;
	gbc.insets = new Insets(3, 3, 3, 3);

	gbc.gridx = 0;
	gbc.gridy = 0;
	gbc.gridwidth = 3;
	gbc.gridheight = 3;
	gbc.weightx = 3d;
	gbc.weighty = 3d;
	cont.add(grandeCont, gbc);

	gbc.gridx = 3;
	gbc.gridy = 0;
	gbc.gridwidth = 1;
	gbc.gridheight = 1;
	gbc.weightx = 1d;
	gbc.weighty = 1d;
	cont.add(petiteCont, gbc);

	gbc.gridx = 3;
	gbc.gridy = 1;
	gbc.gridwidth = 1;
	gbc.gridheight = 2;
	gbc.weightx = 1d;
	gbc.weighty = 2d;
	cont.add(buttonBox, gbc);

	gbc.gridx = 0;
	gbc.gridy = 3;
	gbc.gridwidth = 4;
	gbc.gridheight = 1;
	gbc.weightx = 0d;
	gbc.weighty = 0d;
	cont.add(statusBar, gbc);

    }

    
    /**
     * Renvoi la liste des menus � ajouter � la fenetre principale
     * ne contient pas de menu pour quit et configure.
     */

    public List getMenus() {

	List ret = new ArrayList();

	// menu figure status

	JMenu m3 = new JMenu(i18n.getString("menu.status"));
	m3.add(i18n.getString("menu.status.current")).addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    config.setSolved(actualName, actualFigNr, false);
		    petiteArea.setSolved(false);
		}
	    });
	m3.add(i18n.getString("menu.status.file")).addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    config.clearSolved(actualName);
		    petiteArea.setSolved(false);
		}
	    });
	m3.add(i18n.getString("menu.status.all")).addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    config.clearAllSolved();
		    petiteArea.setSolved(false);
		}
	    });
	
	ret.add(m3);

	// menu info (about et help)


	return ret;
    }


    /**
     * Change la figure mod�le.
     * 
     * @param nr le num�ro de la figure.
     */

    private void changeDisplayFigure(int nr) {
	
	actualFigNr = nr;

	CalcFigure cf = ((CalcFigure.StoredFigure) actualList.get(nr)).getCalcFigure();
	DisplayFigure dfE = new DisplayFigure(cf);
	DisplayFigure dfD = new DisplayFigure(cf);
	grandeArea.setOutlineFigure(dfE);
	petiteArea.setFigure(dfD, config.isSolved(actualName, actualFigNr));
    }


    /**
     * Prend en compte les modifs de la config.
     * N'est pas appell� � l'init.
     */

    public void update(Observable obs, Object obj) {
	
	if ( DEBUG ) {
	    System.err.println("mainwin update");
	}

//  	try {
//  	    Thread.sleep(1000);
//  	} catch (Exception e) {
//  	    e.printStackTrace();
//  	} 

	Config cf = (Config) obs;

	FigureGroup fli = cf.getFigureGroup("main.figureList");
	if ( !actualName.equals(fli.getName())) {
	    actualList = fli.getListNoError();
	    actualName = fli.getName();
	    actualFigNr = 0;
	    
	    figNrReSet(actualList.size());

//  	    changeDisplayFigure(0);
	} 	

	statusBar.setVisible(cf.getBoolean("main.showStatus", true));

//  	petiteArea.config(config);
//  	grandeArea.config(config);
//  	petiteArea.repaint();
//  	grandeArea.refreshAll();
    }


    /**
     * Initialise le composant g�rant le numero de la figure en cours.
     *
     * @return un Container contenant un JSpinner ou un JSlider
     */

    private Container figNrInit(int max) {

	Container ret;
	final String title = i18n.getString("button.actualFig") + " ";
	
	try {
	    // on essai avec un JSpinner (jdk 1.4+)

	    Class modelClass = Class.forName("javax.swing.SpinnerNumberModel");
	     
	    Constructor modelConstructor = modelClass.getConstructor( new Class[] {
		Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE });

	    Object model = modelConstructor.newInstance( new Object[] {
		new Integer(1), new Integer(1), new Integer(max), new Integer(1)} );

	    Class spinnerClass = Class.forName("javax.swing.JSpinner");

	    Constructor spinnerConstructor = spinnerClass.getConstructor( new Class[] {
		Class.forName("javax.swing.SpinnerModel") });

	    Object spinner = spinnerConstructor.newInstance( new Object[] {
		model } );

	    Method addMethod = spinnerClass.getMethod("addChangeListener", new Class[] {
		ChangeListener.class} );
	    
	    final Method getValMethod = spinnerClass.getMethod("getValue", null);
	    
	    addMethod.invoke(spinner, new Object[] {
		new ChangeListener() {
			private Object[] dum = new Object[0];

			public void stateChanged(ChangeEvent e) {
			    int val;
			    try {
				// pas s�r que null soit l�gal
				val = ((Integer) getValMethod.invoke(e.getSource(), dum)).intValue() - 1;
				
			    } catch (Exception ex) {
				ex.printStackTrace(System.err);
				val = 0;
			    } 
			    
			    changeDisplayFigure(val);
			}
		    }
	    });

	    setMaxMethod = modelClass.getMethod("setMaximum", new Class[] { Comparable.class });
	    setValMethod = modelClass.getMethod("setValue", new Class[] { Object.class });
	    setValMaxObject = model;

	    JLabel jl = new JLabel(title);
	    Dimension d = jl.getMinimumSize();
  	    d.width = 50;  // si n�cessaire priorit� au spinner 
	    jl.setMinimumSize(d);

	    ret = Box.createHorizontalBox();
	    ret.add(jl);
	    ret.add((JComponent) spinner);

//      	    throw new RuntimeException("glups");

	} catch (Exception e) {
	    System.err.println("*INFO*: JSpinner not available, falling back to JSlider");
	    
	    // sinon on se rabat sur un JSlider

	    final TitledBorder bd = BorderFactory.createTitledBorder( BorderFactory.createEtchedBorder(),
								      title + "1");

	    JSlider js = new JSlider(1, actualList.size(), 1);
	    js.setBorder(bd);
	    js.addChangeListener(new ChangeListener() {
		    public void stateChanged(ChangeEvent e) {
			JSlider src = (JSlider) e.getSource();
			int newFigNr = src.getValue() - 1;
			
//  			System.out.println("*aa*:" + actualFigNr + ":" + newFigNr);
			
//  			// bugg� pour (au moins) certaines versions du JRE 1.2.2
//  			if ( !src.getValueIsAdjusting() ) {
//  			    changeDisplayFigure(newFigNr);
//  			} 

			// workaround
			if (newFigNr != actualFigNr) {
  			    changeDisplayFigure(newFigNr);
			} 

			bd.setTitle(title + (newFigNr + 1));
			src.repaint();
		    }
		});

	    setValMaxObject = js;
	    setMaxMethod = null;
	    setValMethod = null;

	    ret = js;
	}

	return ret;
    }	


    /**
     * Change la valeur max du composant du numero de figure.
     * Le numero est remis � 1.
     */

    private void figNrReSet(int max) {

	if ( setMaxMethod != null ) {
	    // version JSpinner

	    try {
		Object[] args = new Object[1];
		args[0] = new Integer(1);
		setValMethod.invoke(setValMaxObject, args);
		args[0] = new Integer(max);
		setMaxMethod.invoke(setValMaxObject, args);
	    } catch (Exception e) {
		e.printStackTrace(System.err);
	    }
	} else {
	    // version JSlider
//  	    System.out.println("reset val");
	    
	    // workaround du bug du JRE 1.2.2
  	    actualFigNr = -1;

	    JSlider js = (JSlider) setValMaxObject;

// wa  	    js.setValueIsAdjusting(true); //pour avoir 1 �v�nement (sinon 0, 1 ou 2)
	    js.setValue(1);
	    js.setMaximum(max);
// wa  	    js.setValueIsAdjusting(false);
	}
    }
}    

