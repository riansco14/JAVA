
package net.phbwt.jtans.guimain;

import net.phbwt.jtans.guicommon.*;
import net.phbwt.jtans.calc.*;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;


public final class DisplayFigureComponent extends JPanel implements Observer {

    private static final boolean DEBUG = false;

    private static final int IN_BORDER = 5;  // largeur de la zone non dessin�e 

    private boolean gfxIsConfigured = false;

    // le fond et les pieces (unsel et sel)
    private Surface bgSurface;
    private Paint bgPaint;
    private Surface solvedSurface;
    private Paint solvedPaint;
    private Surface unselectedFiguresSurface;
    private Paint unselectedFiguresPaint;
    private Surface selectedFigureSurface;
    private Paint selectedFigurePaint;

    // rendering hints
    private RenderingHints hints;

    private double refScale = 0.1;

    // d�ja r�solue ?
    public static boolean solved;

    public DisplayFigure fig;


    DisplayFigureComponent(DisplayFigure df, Config cf, boolean s) {
	setOpaque(true);
	setDoubleBuffered(true);
	
	fig = df;
	solved = s;

	config(cf);
	cf.addObserver(this);

	// changement de taille
	this.addComponentListener(new ComponentAdapter() {
		public void componentResized(ComponentEvent e) {
		    resetFigureScale();
		    repaint();

		    if ( DEBUG ) {
			System.err.println("taille");
		    }
		}
	    });
    }
    

    /**
     * Prend en compte les modifs de la config.
     * N'est pas appell� � l'init.
     */

    public void update(Observable obs, Object obj) {

	if ( DEBUG ) {
	    System.err.println("displayfig update");
	}

	config((Config) obs);
	repaint();
    }


    /**
     *  Recup�re les param�tres dans la config.
     */

    public void config(Config cf) {
	
	if ( DEBUG ) {
	    System.err.println("displayfig config");
	}

	unselectedFiguresSurface = cf.getSurface("small.piece.normal");

	selectedFigureSurface = cf.getSurface("small.piece.selected");

	bgSurface = cf.getSurface("small.background.normal");

	solvedSurface = cf.getSurface("small.background.solved");

	hints = cf.getRenderingHints();

	//provoque une reconfig graphique
	gfxIsConfigured = false;

    }


    /**
     * post config (n�cessitant un contexte graphique).
     */

    private void configGfx() {

	if ( DEBUG ) {
	    System.err.println("displayfig config gfx");
	}	

	unselectedFiguresPaint = unselectedFiguresSurface.getPaintNoError(this); 
	selectedFigurePaint = selectedFigureSurface.getPaintNoError(this); 
	bgPaint = bgSurface.getPaintNoError(this); 
	solvedPaint = solvedSurface.getPaintNoError(this); 
	

	
	gfxIsConfigured = true;
    }


    public void paintComponent(Graphics g){

	if ( DEBUG ) {
	    System.err.println("displayfig paint");
	}

	if ( !gfxIsConfigured ) {
	    configGfx();
	} 

	Graphics2D g2 = (Graphics2D) g;
	Stroke oldStroke = g2.getStroke();

	Insets in = getInsets();
	int x = in.left;
	int y = in.top;
	int w = getWidth() - in.left - in.right;
	int h = getHeight() - in.top - in.bottom;
	    
	// le fond
	g2.setPaint(solved ? solvedPaint : bgPaint);
	g2.fill(new Rectangle(x, y, w, w));
	
	// l'outline
	g2.setPaint(unselectedFiguresPaint);
	int state = 0;
	for ( Iterator i = fig.outlineIterator(); i.hasNext(); ) {
	    PixelOutlinePolygon p = (PixelOutlinePolygon) i.next();

	    if ( state == 0 && p.getType() == CalcOutlinePolygon.ON ) {
  		g2.setPaint(bgPaint);
//    		g2.setPaint(Color.red); // *test*
		state++;
	    } else if ( state == 1 && p.getType() == CalcOutlinePolygon.NORMAL ){
  		g2.setPaint(unselectedFiguresPaint);
//    		g2.setPaint(Color.blue); // *test*
		state++;
	    } 
	    
  	    g2.fill(p); 
//  	    g2.draw(p); // *test*
	} 

	// dessin de la shape selectionn�e
	Shape s = fig.getSelectedPiece();
	if ( s != null ) {
  	    g2.setPaint(selectedFigurePaint);
//    	    g2.setPaint(Color.red);
//      	    g2.setPaint(bgPaint);
	    g2.fill(s);
	} 

	g2.setStroke(oldStroke);
    }
    
    
    public void selectNext() {
	fig.selectNext();
    }


    public void setFigure(DisplayFigure df, boolean s) {
	solved = s;
	fig = df;
	resetFigureScale();
	repaint();
    }


    public void setSolved(boolean s) {
	solved = s;
	repaint();
    }


    /**
     * Ajuste la taille de la figure � celle de composant.
     */

    private void resetFigureScale() {
	Insets in = getInsets();
	fig.resetCoords( in.left + IN_BORDER,
			 in.top + IN_BORDER,
			 getWidth() - in.right - IN_BORDER,
			 getHeight() - in.bottom - IN_BORDER );
    }


    protected final Graphics getComponentGraphics(Graphics g) {
	((Graphics2D) g).addRenderingHints(hints);
	return g;
    }
}

