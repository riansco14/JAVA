
package net.phbwt.jtans.calc;


/**
 * Petit Triangle
 */

public final class CalcPiecePT extends CalcPiece {
    
	
    CalcPiecePT(double x, double y, double r, boolean fl) {
	super(x, y, r, fl);
    }


    public void setFigure(CalcFigure cf) {
	init(cf, 3, 2);
    }


//      private void readObject( ObjectInputStream in )
//  	throws IOException, ClassNotFoundException {

//  	in.defaultReadObject();

//  	initTransient(3, 2);
//      }


    public CalcPolyPoints getPolygon() {

	if ( polygonLastChange != pieceChangeCount ) {
		
	    double rot = rotation;
	    
	    if ( isFlipped ) {
		rot += Math.PI;
	    } 
	    
	    double rotCos = Math.cos(rot);
	    double rotSin = Math.sin(rot);
	    
	    double prex = posX - (rotCos + rotSin) / 3.0;
	    double prey = posY + (rotSin - rotCos) / 3.0;
	    
	    xt[0] = prex;
	    yt[0] = prey;
	    xt[1] = prex + rotCos;
	    yt[1] = prey - rotSin;
	    xt[2] = prex + rotSin;
	    yt[2] = prey + rotCos;

	    polygonLastChange = pieceChangeCount;		
	} 
	
	return calcPolygon;
    }


    public void putInTinyTab() {
	if ( pieceTinyLastChange != pieceChangeCount ) {
		
	    double rot = rotation;
		
	    if ( isFlipped ) {
		rot += Math.PI;
	    } 
		
	    double rotCos = Math.cos(rot);
	    double rotSin = Math.sin(rot);
		
	    double prex = posX - (rotCos + rotSin) / 3.0;
	    double prey = posY + (rotSin - rotCos) / 3.0;
	
	    int index = tinyTabIndex;

	    index = putSmallTriangleAt( index,
					prex,
					prey,
					rot );
		
//  		index = putSmallTriangleAt( index,
//  				 prex + XX * rotCos + YY * rotSin,
//  				 prey - XX * rotSin + YY * rotCos,
//  				 rot + RR * HT );
		
	
	    pieceTinyLastChange = pieceChangeCount;		
	}	
    }
}
