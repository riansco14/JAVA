
package net.phbwt.jtans.calc;


/**
 * Polygone d'affichage bas� sur une CalcPiece.
 */

public final class PixelPiece extends PixelPolygon {

    private CalcPiece calcPiece;  // la piece float correspondante 


    public PixelPiece(PixelFigure f, CalcPiece cp) {
	
	super(f, cp.getPolygon().npoints);

	calcPiece = cp;

	resetShape();
    }


    /**
     * N�cessaire � la superclasse. 
     */

    protected CalcPolyPoints getPolygon() {
	return calcPiece.getPolygon();
    }


    /**
     * Translate la pi�ce.
     */

    public void translate(int dx, int dy) {
	
	super.translate(dx, dy);

	calcPiece.translate(dx / figure.scale, dy / figure.scale);
    }


    /**
     * Flip la pi�ce.
     */ 

    public void flip() {
	calcPiece.flip();
	resetShape();
    }


    /**
     * 
     */ 

    public void setRotation(double r) {
	calcPiece.setRotation(r);
	resetShape();
    }


    /**
     * 
     */ 

    public double getRotation() {
	return calcPiece.rotation;
    }


    /**
     * 
     */ 

    public int getPosX() {
	return (int)(calcPiece.posX * figure.scale + ARON) + figure.refX;
    }


    /**
     * 
     */ 

    public int getPosY() {
	return (int)(calcPiece.posY * figure.scale + ARON) + figure.refY;
    }


    /**
     * Teste si la pi�ce contient le point.
     * Float plutot que int pour factoriser le changement de referentiel. 
     */

    public boolean contains(double x, double y) {
	return calcPiece.contains(x, y);
    }
}
