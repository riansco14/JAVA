
package net.phbwt.jtans.calc;

import java.io.StreamTokenizer;
import java.io.IOException;


/**
 * Element de la figure.
 * Doit �tre initialis� avant utilisation en appelant setFigure().
 */

public abstract class CalcPiece {
    
    // constantes de calcul
    protected static final double CL = 1.4142135624;
    protected static final double CC = CL / 2;
    public static final double HT = Math.PI / 4;  // 1/8�me de tour
    
    protected CalcFigure figure;  // la figure dont fait partie cette pi�ce 

    // attributs de base
    // doivent �tre modifi�s en passant par les accesseurs
    public double posX, posY;
    public double rotation;
    public boolean isFlipped;

    // gestion de la liste de tiny tri 
    protected int tinyTabIndex;        // l'index du premier tiny dans la table de la figure
    protected int pieceTinyLastChange;

    // gestion du polygone (en flottant)
    protected CalcPolyPoints calcPolygon;
    protected double[] xt;
    protected double[] yt;
    protected int polygonLastChange;

    protected int pieceChangeCount;    // doit �tre increment� � chaque modif de la pi�ce. 

	
    /**
     * Constructeur de base pour les sous classes.
     */

    protected CalcPiece(double x, double y, double r, boolean fl) {

	posX = x;
	posY = y;
	rotation = r;
	isFlipped = fl;
    }


    /**
     * Initialisation diverses.
     *
     * @param pn nombre de points du polygone de la pi�ce.
     * @param tn nombre de tiny triangles composant la pi�ce.
     */

    protected void init(CalcFigure fi, int pn, int tn) {
	figure = fi;

	tinyTabIndex = figure.figureTinyTab.calcIndex(tn);
	pieceTinyLastChange = -1;

	calcPolygon = new CalcPolyPoints(pn);
	polygonLastChange = -1;
	xt = calcPolygon.xpoints;
	yt = calcPolygon.ypoints;

	pieceChangeCount = 0;
    }


    /**
     * (Re)calcule le polygone (en flottant) de la figure.
     */

    public abstract CalcPolyPoints getPolygon();


    /**
     * Place les tiny triangles dans le CalcPolyTriangles de la figure.
     * A l'endroit d�termin� lors de l'instanciation (i.e. tinyTabIndex).
     */

    public abstract void putInTinyTab();
    

    /**
     * Initialise la pi�ce.
     * Typiquement appelle init(). 
     */

    public abstract void setFigure(CalcFigure cf);


    public void setRotation(double rot){

	rotation = rot;
	
	pieceChangeCount++;
	figure.figureChangeCount++;
    }

  
    public void flip() {
	isFlipped = ! isFlipped;
	
	pieceChangeCount++;
	figure.figureChangeCount++;
    }


    public void setPosition(double x, double y){
	posX = x;
	posY = y;
	
	pieceChangeCount++;
	figure.figureChangeCount++;
    }
  
    
    public void translate(double dx, double dy){
	posX += dx;
	posY += dy;
	
	pieceChangeCount++;
	figure.figureChangeCount++;
    }
    

    public boolean contains(double x, double y) {
	
	// recalcul si n�cessaire;
	calcPolygon = getPolygon();

	int i;
	for (i = 0; i< calcPolygon.npoints - 1; i++ ) {
	    if ( (x - xt[i]) * (yt[i + 1] - yt[i]) - (y - yt[i]) * (xt[i + 1] - xt[i]) > 0 ) {
		return false;
	    }
	} 
	
	// le segment de fermeture
	if ( (x - xt[i]) * (yt[0] - yt[i]) - (y - yt[i]) * (xt[0] - xt[i]) > 0 ) {
	    return false;
	}

	return true;
    }

 
    private static final double SMALL_C1 = 0.5;              // constante pour les calculs
    private static final double SMALL_C2 = 0.16666666666666; // idem
    
    
    /**
     * Ajoute les (deux) tinyTriangles correspondants a un small triangle.
     */

    protected int putSmallTriangleAt( int idx,
				      double smallX,
				      double smallY,
				      double smallRot ) {
	
	double rotCos = Math.cos(smallRot);
	double rotSin = Math.sin(smallRot);
	
	figure.figureTinyTab.putTriangleAt( idx++,
					    smallX + SMALL_C1 * rotCos + SMALL_C2 * rotSin,
					    smallY + SMALL_C2 * rotCos - SMALL_C1 * rotSin,
					    normalizeAngle(smallRot + CalcPiece.HT * 3) );
	
	figure.figureTinyTab.putTriangleAt( idx++,
					    smallX + SMALL_C2 * rotCos + SMALL_C1 * rotSin,
					    smallY + SMALL_C1 * rotCos - SMALL_C2 * rotSin,
					    normalizeAngle(smallRot + CalcPiece.HT * 5) );
	
	return idx;
    }


    /**
     *
     */
    
    public String toString() {
	
	return "("
	    + getClass().getName()
	    + ":x=" + posX
	    + ":y=" + posY
	    + ":r=" + rotation
	    + ":f=" + isFlipped
	    + ")";
    }


    /**
     * Renvoi un angle compris entre 0 et 2 PI. 
     */

    public static double normalizeAngle(double angle) {
	angle %= 2 * Math.PI;
	if ( angle < 0) {
	    angle += 2 * Math.PI;
	} 
	return angle;
    }

    
    StoredPiece getStoredPiece() {
	return new StoredPiece(this);
    }


    /**
     * Version all�g�e.
     * Contient le minimum d'attribut et des m�thodes de conversion avec le format
     * des fichiers gTans.
     */

    public static class StoredPiece {

	private double posX, posY;
	private double rotation;
	private boolean isFlipped;
	private byte type;


	/**
	 * CalcPiece -> StoredPiece.
	 */

	private StoredPiece(CalcPiece cp) {

	    this.posX = cp.posX;
	    this.posY = cp.posY;
	    this.rotation = cp.rotation;
	    this.isFlipped = cp.isFlipped;

	    if ( cp instanceof CalcPieceGT ) {
		this.type = 0;
	    } else if ( cp instanceof CalcPieceMT ) {
		this.type = 1;
	    } else if ( cp instanceof CalcPieceC ) {
		this.type = 2;
	    } else if ( cp instanceof CalcPieceT ) {
		this.type = 3;
	    } else if ( cp instanceof CalcPiecePT ) {
		this.type = 4;
	    }
	}


	/**
	 * StoredPiece -> CalcPiece.
	 */

	CalcPiece getCalcPiece() {
	    
	    CalcPiece cp;

	    switch ( type ) {
	    case 0:
		cp = new CalcPieceGT(posX, posY, rotation, isFlipped); 
		break;
		
	    case 1:
		cp = new CalcPieceMT(posX, posY, rotation, isFlipped); 
		break;
		
	    case 2:
		cp = new CalcPieceC(posX, posY, rotation, isFlipped); 
		break;
		
	    case 3:
		cp = new CalcPieceT(posX, posY, rotation, isFlipped); 
		break;
		
	    case 4:
		cp = new CalcPiecePT(posX, posY, rotation, isFlipped); 
		break;
		
	    default:
		throw new RuntimeException("shouldn't occur");
	    }

	    return cp;
	}


	/**
	 * Constructeur lisant dans un fichier au format gTans.
	 *
	 * @param st doit �tre en mode eolIsSignificant(true) et parseNumber().
	 */

	StoredPiece(StreamTokenizer st) throws IOException {

	    // p
	    if ( st.nextToken() != StreamTokenizer.TT_WORD ||
		 !"p".equals(st.sval) ) {
		throw new RuntimeException("bad piece format : line=" + st.lineno());
	    }

	    try {
		st.nextToken();
		type = Byte.parseByte(st.sval);
		
		st.nextToken();
		isFlipped = Integer.parseInt(st.sval) == 1;
		
		st.nextToken();
		posX = Double.parseDouble(st.sval);
		
		st.nextToken();
		posY = Double.parseDouble(st.sval);
		
		st.nextToken();
		rotation = normalizeAngle(Integer.parseInt(st.sval) * 2d * Math.PI / 65536d);
		
	    } catch (NumberFormatException e) {
		throw new RuntimeException("bad piece format : line = " + st.lineno());
	    } 
	    
	    // eol
	    if ( st.nextToken() != StreamTokenizer.TT_EOL ) {
		throw new RuntimeException("bad piece : expecting eol : line=" + st.lineno());
	    }
	}


	/**
	 * Convertit en String au format gTans. 
	 */

	public String toString() {
	    return "p " + type
		+ (isFlipped ? " 1 " : " 0 ")
		+ posX + " " + posY
		+ " " + Math.round(normalizeAngle(rotation) * 32768 / Math.PI)
		+ "\n";
	}
    }
}

