
package net.phbwt.jtans.calc;

import java.util.*;


/**
 * Superclasse des figures affichable.
 * Contient les attributs n�cessaires au changement de r�f�rentiel.
 * Ainsi que la gestion de l'outline.
 */

public abstract class PixelFigure {

    private static final boolean DEBUG = false;

    // changement de r�f�rentiel (ref. de calcul -> ref. d'affichage)
    protected double scale = 30;
    protected int refX = 0, refY = 0;

    // la figure float correspondante
    protected CalcFigure calcFig;
    protected List calcOutlinePolygons;
    protected List guiOutlinePolygons;


    public Iterator outlineIterator() {

	List cop = calcFig.getOutlinePolygons();

	if ( cop != calcOutlinePolygons || guiOutlinePolygons == null ) {
	    
	    if ( DEBUG ) {
		System.out.println("reconstruit liste de polygones gui outlines");
	    }

	    guiOutlinePolygons = new ArrayList();
	    for ( Iterator i = cop.iterator(); i.hasNext(); ) {
		guiOutlinePolygons.add( new PixelOutlinePolygon( this,
								 (CalcOutlinePolygon)i.next() ) );
	    } 
	    
	    calcOutlinePolygons = cop;
	}
	
	return guiOutlinePolygons.iterator();


//  	return new Iterator() {
		
//  		Iterator calcIter = calcFig.outlinePolygonIterator();

//  		public boolean hasNext() {
//  		    return calcIter.hasNext();
//  		}

//  		public Object next() {
//  		    return new PixelOutlinePolygon(PixelFigure.this, (CalcOutlinePolygon)calcIter.next());

//  		}
		
//  		public void remove() {
//  		    throw new UnsupportedOperationException();
//  		}
//  	    };
    }


    protected void reset() {

	if ( guiOutlinePolygons != null ) {
	    for ( Iterator i = guiOutlinePolygons.iterator(); i.hasNext(); ) {
		
		((PixelPolygon)i.next()).resetShape();
		
	    } 
	} 
    }

    
    public CalcFigure getCalcFigure() {
	return calcFig;
    }
}

