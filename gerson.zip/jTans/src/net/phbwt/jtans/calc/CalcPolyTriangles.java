
package net.phbwt.jtans.calc;


/**
 * liste de triangles.
 * Sur le mod�le de Polygon.
 * Le nombre de points est donn� par ntriangles, PAS par la taille des tableaux.
 */

public final class CalcPolyTriangles {

    public double[] xtriangles;
    public double[] ytriangles;
    public double[] rtriangles;

    public int ntriangles;


    CalcPolyTriangles(int nbr) {
	ntriangles = 0;
	xtriangles = new double[nbr];
	ytriangles = new double[nbr];
	rtriangles = new double[nbr];
    }

 
//      TinyTab(double[] x, double[] y, double[] r) {
//  	ntriangles = x.length;
//  	this.xtriangles = x;
//  	this.ytriangles = y;
//  	this.rtriangles = y;
	
//      }


    /**
     * Calcule la position pour de nouveaux triangles.
     * 
     * @return l'index du premier des triangles.
     */
    
    public int calcIndex(int nb) {
	ntriangles += nb;
	
	return ntriangles - nb;
    }


    /**
     * Place un triangle � la position indiqu�e.
     */

    public void putTriangleAt(int idx, double x, double y, double r) {
	xtriangles[idx] = x;
	ytriangles[idx] = y;
	rtriangles[idx] = r;
    } 
}
