
package net.phbwt.jtans.calc;


/**
 * Polygone d'affichage bas� sur un polygone fl..
 */

public final class PixelOutlinePolygon extends PixelPolygon {

    private CalcOutlinePolygon calcPolygon;


    public PixelOutlinePolygon(PixelFigure f, CalcOutlinePolygon cop) {
	
	super(f, cop.npoints);

	calcPolygon = cop;

	resetShape();
    }


    /**
     * N�cessaire � la superclasse. 
     */

    protected CalcPolyPoints getPolygon() {
	return calcPolygon;
    }


    /**
     * 
     */

    public int getType() {
	return calcPolygon.type;
    }
}
