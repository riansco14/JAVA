
package net.phbwt.jtans.calc;


/**
 * Carre
 */

public final class CalcPieceC extends CalcPiece {
    

    CalcPieceC(double x, double y, double r, boolean fl) {
	super(x, y, r, fl);
    }


    public void setFigure(CalcFigure cf) {
	init(cf, 4, 4);
    }


//      private void readObject( ObjectInputStream in )
//  	throws IOException, ClassNotFoundException {

//  	in.defaultReadObject();

//  	initTransient(4, 4);
//      }


    public CalcPolyPoints getPolygon() {

	if ( polygonLastChange != pieceChangeCount ) {
	    
	    double rot = rotation;
	    
//  		if ( isFlipped ) {
//  		    rot += Math.PI;
//  		} 
	    
	    double rotCos = Math.cos(rot);
	    double rotSin = Math.sin(rot);
	    
	    double prex = posX - (rotCos + rotSin) * 0.5;
	    double prey = posY + (rotSin - rotCos) * 0.5;
	    
	    xt[0] = prex;
	    yt[0] = prey;
	    xt[1] = prex + rotCos;
	    yt[1] = prey - rotSin;
	    xt[2] = prex + rotCos + rotSin;
	    yt[2] = prey + rotCos - rotSin;
	    xt[3] = prex + rotSin;
	    yt[3] = prey + rotCos;

	    polygonLastChange = pieceChangeCount;		
	} 
	
	return calcPolygon;
    }


    public void putInTinyTab() {
	if ( pieceTinyLastChange != pieceChangeCount ) {
		
	    double rot = rotation;
		
//  		if ( isFlipped ) {
//  		    rot += Math.PI;
//  		} 
		
	    double rotCos = Math.cos(rot);
	    double rotSin = Math.sin(rot);
		
	    double prex = posX - (rotCos + rotSin) * 0.5;
	    double prey = posY + (rotSin - rotCos) * 0.5;
	
	    int index = tinyTabIndex;

	    index = putSmallTriangleAt( index,
					prex,
					prey,
					rot );
		
	    index = putSmallTriangleAt( index,
					prex + rotCos + rotSin,
					prey - rotSin + rotCos,
					rot + 4.0 * HT );
		
//  		index = putSmallTriangleAt( index,
//  				 prex + XX * rotCos + YY * rotSin,
//  				 prey - XX * rotSin + YY * rotCos,
//  				 rot + RR * HT );
		
	
	    pieceTinyLastChange = pieceChangeCount;		
	}	
    }
}
