
package net.phbwt.jtans.calc;

import java.awt.*;
import java.util.*;


/**
 * Figure en coordonn�es d'affichage (i.e. en pixel) affichant (sans la modifier)
 * une CalcFigure encapsul�e.
 * Essentiellement g�re une pi�ce selectionn�e et le 'changement de referentiel'.
 */

public class DisplayFigure extends PixelFigure {

    // pi�ce s�lectionn�e
    private Iterator selectedPieceIterator = null;  // null si pas de piece selectionn�e
    private PixelPiece selectedDisplayPiece = null;   // idem


    public DisplayFigure(CalcFigure figure) {
	calcFig = figure;
    }


    public void setRef(int x, int y, double s) {
	refX = x;
	refY = y;
	scale = s;

	if ( selectedDisplayPiece != null ) {
	    selectedDisplayPiece.resetShape();
	} 

	super.reset();
    }


    public void setScale(double s) {
	setRef(0, 0, s);
    }


    public void unselect() {
	selectedPieceIterator = null;
	selectedDisplayPiece = null;
    }


    public void selectNext() {

	// (re)init l' Iterator si n�cessaire
	if ( selectedPieceIterator == null || !selectedPieceIterator.hasNext() ) {
	    selectedPieceIterator = calcFig.pieceIterator();
	} 
	
	selectedDisplayPiece = new PixelPiece(this, (CalcPiece) selectedPieceIterator.next());
    }


    /**
     * Recalcule le changement de r�f�rentiel pour que la figure affich�e tienne
     * dans le rectangle donn�.
     */

    public void resetCoords(int minX, int minY, int maxX, int maxY) {
	CalcPolyPoints minMax = calcFig.getMinMax();
		    
	double sc = Math.min( (maxX - minX) / (minMax.xpoints[1] - minMax.xpoints[0]),
			      (maxY - minY) / (minMax.ypoints[1] - minMax.ypoints[0]) );

	int rx = (int)( (maxX + minX - (minMax.xpoints[1] + minMax.xpoints[0]) * sc ) / 2 );
	int ry = (int)( (maxY + minY - (minMax.ypoints[1] + minMax.ypoints[0]) * sc ) / 2 );

//  	System.out.println(this);

	setRef(rx, ry, sc);
    }
    

    /**
     * Recalcule la translation pour que la figure soit centr�e
     * dans le rectangle donn�.
     */

    public void center(int minX, int minY, int maxX, int maxY) {
	CalcPolyPoints minMax = calcFig.getMinMax();

	int rx = (int)( (maxX + minX - (minMax.xpoints[1] + minMax.xpoints[0]) * scale ) / 2 );
	int ry = (int)( (maxY + minY - (minMax.ypoints[1] + minMax.ypoints[0]) * scale ) / 2 );

	setRef(rx, ry, scale);
    }
    

    /**
     * Renvoi un polygone Pixel correspondant � la pi�ce selectionn�e.
     *
     * @return la pi�ce ou null si pas de pi�ce selectionn�e.
     */
    
    public Shape getSelectedPiece() {
	return selectedDisplayPiece;
    }


    /**
     *
     */

    public String toString() {
	return "DisplayFigure(scale=" + scale
	    + ", refX=" + refX
	    + ", refY=" + refY
	    + ")";
    }
}
