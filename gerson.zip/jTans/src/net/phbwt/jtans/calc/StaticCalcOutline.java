
package net.phbwt.jtans.calc;

import java.util.*;


/**
 * Classe contenant une seule methode publique (et statique) permettant de calculer le contour d'une figure.
 */

public class StaticCalcOutline {

    private static final boolean DEBUG = false;

    private static final int MAX_PNTS = 100;  // nb. max. de points utilis�s pour les calculs.
    private static final int MAX_POLY = 10;   // nb. max. de Poly utilis�s pour les calculs.

//      private final static double SEUIL_DIST = 1E-11;
//      private final static double SEUIL_ANGLE = Math.PI / 256;
    private static final double SEUIL_DIST = 1E-10;              // *test*
    private static final double SEUIL_ANGLE = Math.PI / 128;     // *test*

    // le buffer de points
    private static CalcPolyPoints pointBuffer = new CalcPolyPoints(0, MAX_PNTS);
    private static double[] xBuf = pointBuffer.xpoints;
    private static double[] yBuf = pointBuffer.ypoints;
    private static int[] nextPoint = new int[MAX_PNTS]; // 'pointeurs' sur le point suivant dans pointBuffer

    // 2�me buffer 
    private static CalcPolyPoints dumBuffer = new CalcPolyPoints(0, MAX_PNTS);

    private static int polyNbr;  // nb. de Poly 
    private static Poly[] polyBuffer = new Poly[MAX_POLY];

    private static CalcPolyPoints delta = new CalcPolyPoints(1);
    private static double[] xDelta = delta.xpoints;
    private static double[] yDelta = delta.ypoints;


    public static synchronized List createOutline(CalcFigure figure) {

	init(figure);

	if ( DEBUG ) {
	    System.out.println("createOutline");
	}

	long time = System.currentTimeMillis(); // *debug*

//  	merge();
//  	removeConsec();

//  	compact();
//    	addInterPoints();
//    	merge();
//    	removeConsec();
//    	if ( checkIncluded() ) {
//    	    checkIncluded();
//    	}
//    	removeAligned();

//    	compact();
//    	addInterPoints();
//      	merge();
//      	removeConsec();
//    	if ( checkIncluded() ) {
//    	    checkIncluded();
//    	}
//    	removeAligned();

//    	compact();
//    	addInterPoints();
//      	merge();
//      	removeConsec();
//    	if ( checkIncluded() ) {
//    	    checkIncluded();
//    	}
//    	removeAligned();

  	merge();
  	removeConsec();

	boolean cont;
	do {
	    cont = false;

	    addInterPoints();
	    
	    cont |= merge();
	    cont |= removeConsec();

	    if ( checkIncluded() ) {
		checkIncluded();
		cont = true;
	    }

	    removeAligned();
	    compact();
	} while (cont);

	// cr�e la collection de polygones fl.
	List polygones = new ArrayList();
	for ( int i = 0; i < polyNbr; i++ ) { // croissant !
	    Poly p = polyBuffer[i];
	    CalcOutlinePolygon cp = new CalcOutlinePolygon(0, p.pointNbr, p.type);

	    int currentPnt = p.firstPoint;
	    for ( int j = p.pointNbr; j > 0; j--) {
		cp.addPoint(xBuf[currentPnt], yBuf[currentPnt]);
		currentPnt = nextPoint[currentPnt];
	    }
	    
	    polygones.add(cp);
	}


	if ( DEBUG ) {
	    System.out.println("calc time" + (System.currentTimeMillis() - time));
	}	

	return polygones;
    }


    /**
     * Initialise les structures � partir d'une CalcFigure.
     */

    private static void init(CalcFigure figure) {

	pointBuffer.clear();
	polyNbr = 0;

	// init des enchainement
	for ( int i = MAX_PNTS - 1; i >= 0; i--) {
	    nextPoint[i] = i + 1;
	} 

	for ( Iterator i = figure.pieceIterator(); i.hasNext(); ) {

	    // ajoute les points
	    CalcPolyPoints cp = ((CalcPiece)i.next()).getPolygon();
	    int first = pointBuffer.addCalcPolyPoints(cp);

//  	    pointBuffer.addPoint(cp.xpoints[0], cp.ypoints[0]); // fermeture du polygone

	    // fermeture dans l'enchainement
	    nextPoint[first + cp.npoints - 1] = first;

	    polyBuffer[polyNbr++] = new Poly(first, cp.npoints);
	} 
    }


    /**
     * Ajoute des points intermediaires.
     */

    private static boolean addInterPoints() {

	int i1, i2, k1, k2;
	int currentPnt1, currentPnt2;
	int nextPnt1, nextPnt2;

	double dx, dy;
	int newPnt;

	boolean ret = false;
	boolean trouve = true;
	while ( trouve ){
	    trouve = false;

	    for ( i1 = polyNbr - 1; i1 >= 0 && !trouve; i1-- ) {

		for ( i2 = polyNbr - 1; i2 >= 0 && !trouve; i2-- ) {

		    if ( i1 != i2 || i1 == i2 ){

			currentPnt1 = polyBuffer[i1].firstPoint;

			for (k1 = polyBuffer[i1].pointNbr; k1 > 0  && !trouve; k1--) {

			    nextPnt1 = nextPoint[currentPnt1];
			    currentPnt2 = polyBuffer[i2].firstPoint;

			    for (k2 = polyBuffer[i2].pointNbr; k2 > 0 && !trouve; k2--) {

				nextPnt2 = nextPoint[currentPnt2];

				if ( pointBuffer.distSqr( currentPnt1,
							  currentPnt2 ) > SEUIL_DIST &&
				     pointBuffer.distSqr( nextPnt1,
							  currentPnt2 ) > SEUIL_DIST &&
				     pointBuffer.distSegSqr( currentPnt1,
							     nextPnt1,
							     currentPnt2,
							     delta ) < SEUIL_DIST/4 ) {

				    if ( i1 == i2 && DEBUG ) {
					System.err.println("*INFO*: **** auto insertion *****");
				    } 
				    

				    // ins�re un point sur le point du segment le plus proche
				    newPnt = pointBuffer.addPoint( xBuf[currentPnt2] - xDelta[0],
								   yBuf[currentPnt2] - yDelta[0] );
				    nextPoint[newPnt] = nextPoint[currentPnt1];
				    nextPoint[currentPnt1] = newPnt;

				    polyBuffer[i1].pointNbr++;
				    polyBuffer[i1].firstPoint = currentPnt1;
				    trouve = ret = true;
				}

				currentPnt2 = nextPnt2;
			    }

			    currentPnt1 = nextPnt1;
			}
		    }
		}
	    }
	}

	return ret;
    }  


    /**
     * Compacte et r�ordonne pointBuffer dans dumBuffer puis swap les deux.
     */

    private static void compact() {
	
	dumBuffer.clear();

	Poly currentPoly;
	int currentPoint;

	// recopie les points dans l'ordre
	for ( int i = polyNbr - 1; i >= 0; i--) {
	    currentPoly = polyBuffer[i];
	    currentPoint = currentPoly.firstPoint;
	    currentPoly.firstPoint = dumBuffer.addPoint(xBuf[currentPoint], yBuf[currentPoint]);
	    for ( int j = currentPoly.pointNbr - 1; j > 0; j--) {  // 1 point de moins 
		currentPoint = nextPoint[currentPoint];
		dumBuffer.addPoint(xBuf[currentPoint], yBuf[currentPoint]);
	    } 
	} 

	// recr�e les enchainements
	for ( int i = polyNbr - 1; i >= 0; i--) {
	    currentPoly = polyBuffer[i];
	    currentPoint = currentPoly.firstPoint;
	    for ( int j = currentPoly.pointNbr - 1; j > 0; j--) {
		nextPoint[currentPoint] = currentPoint + 1;
		currentPoint++;
	    } 
	    nextPoint[currentPoint] = currentPoly.firstPoint;
	} 

	// swap les buffers
	CalcPolyPoints cp = dumBuffer;
	dumBuffer = pointBuffer;
	pointBuffer = cp;
	xBuf = pointBuffer.xpoints;
	yBuf = pointBuffer.ypoints;
    }


    /**
     * Parcours les polygones et supprime les points intermediaires
     * correspondant � des segments successifs align�s.
     */

    private static boolean removeAligned() {

	int i,k;

	int currentPnt, nextPnt, nextNextPnt;
	double currentDir, nextDir;

	double dirDiff;
  
	boolean ret = false;
	boolean trouve = true;
	while (trouve){
	    
	    trouve = false;
	    
	    for (i = polyNbr - 1; i >= 0 && !trouve; i--) {
		
		currentPnt = polyBuffer[i].firstPoint;
		nextPnt = nextPoint[currentPnt];

		currentDir = pointBuffer.angle( nextPnt, currentPnt );

//  		currentDir = (int)((dumi + rotstepnbr / 2) / rotstepnbr);
      
		for (k = polyBuffer[i].pointNbr; k > 0 && !trouve; k--) {
		    
		    nextPnt = nextPoint[currentPnt];
		    nextNextPnt = nextPoint[nextPnt];

		    nextDir = pointBuffer.angle( nextNextPnt, nextPnt );

//  		    nextDir = (int)((dumi + rotstepnbr / 2) / rotstepnbr);
		    
		    dirDiff = nextDir - currentDir;
		    if ( ( dirDiff < SEUIL_ANGLE && dirDiff > -SEUIL_ANGLE ) ||
			 dirDiff > Math.PI * 2 - SEUIL_ANGLE ||
			 dirDiff < -(Math.PI * 2 - SEUIL_ANGLE) ) {
			
			nextPoint[currentPnt] = nextNextPnt;
			polyBuffer[i].pointNbr--;
			polyBuffer[i].firstPoint = currentPnt;
			trouve = ret = true;
		    }

		    currentPnt = nextPnt;
		    currentDir = nextDir;
		}
	    }
	}
	
	return ret;
    }


    /**
     * Supprime les segments cons�cutifs superpos�s.
     */

    private static boolean removeConsec() {

	int i,k;
	int currentPnt, nextPnt, nextNextPnt;
	
	boolean ret = false;
	boolean trouve = true;

	while (trouve){

	    trouve = false;

	    for (i = polyNbr - 1; i >= 0 && !trouve; i--) {

		currentPnt = polyBuffer[i].firstPoint;

		for (k = polyBuffer[i].pointNbr; k > 0 && !trouve; k--) {

		    nextPnt = nextPoint[currentPnt];
		    nextNextPnt = nextPoint[nextPnt];

		    if ( pointBuffer.distSqr(currentPnt, nextNextPnt) < SEUIL_DIST ) {

			nextPoint[currentPnt] = nextPoint[nextNextPnt];
			polyBuffer[i].pointNbr -= 2;
			polyBuffer[i].firstPoint = currentPnt;
			trouve = ret = true;
		    }

		    currentPnt = nextPnt;
		}
	    }
	}
	
	return ret;
    }


    /**
     * Concat�ne les polys ayant 1 segment commun.
     */

    private static boolean merge() {

	int i1, i2, k1, k2, m;
	int currentPnt1, currentPnt2;
	int nextPnt1, nextPnt2;
  
	boolean ret = false;
	boolean trouve = true;

	while ( trouve ){

	    trouve = false;

	    for ( i1 = polyNbr - 1; i1 >= 0 && !trouve; i1-- ) {

		for ( i2 = i1 + 1; i2 < polyNbr && !trouve; i2++ ) {

		    currentPnt1 = polyBuffer[i1].firstPoint;

		    for ( k1 = polyBuffer[i1].pointNbr; k1 > 0 && !trouve; k1-- ) {

			nextPnt1 = nextPoint[currentPnt1];

			currentPnt2 = polyBuffer[i2].firstPoint;

			for ( k2 = polyBuffer[i2].pointNbr; k2 > 0 && !trouve; k2-- ) {

			    nextPnt2 = nextPoint[currentPnt2];

			    if ( pointBuffer.distSqr( currentPnt1, nextPnt2 ) < SEUIL_DIST &&
				 pointBuffer.distSqr( nextPnt1, currentPnt2 ) < SEUIL_DIST ) {

				nextPoint[currentPnt1] = nextPoint[nextPnt2];
				nextPoint[currentPnt2] = nextPoint[nextPnt1];
				polyBuffer[i1].pointNbr += polyBuffer[i2].pointNbr - 2;
				polyBuffer[i1].firstPoint = currentPnt1;

				for (m = i2; m < polyNbr - 1; m++) {
				    polyBuffer[m] = polyBuffer[m + 1];
				}

//  				System.arraycopy( polyBuffer, i2 + 1, polyBuffer, i2, polyNbr - i2 - 1 );

				polyNbr--;
				trouve = ret = true;
			    }

			    currentPnt2 = nextPnt2;
			}

			currentPnt1 = nextPnt1;
		    }
		}
	    }
	}

	return ret;
    }  


    /**
     * G�re les poly 'inclus'.
     * En se basant sur des segment superpos�s mais non cons�cutifs..
     * Probl�me potentiel : pourrait ne pas d�tecter une inclusion
     * car on n'ajoute pas de points pour les 'auto-corespondance'
     * Remarque : commentaire de gTans, je ne sais plus � quoi
     * �a correspond.
     */

    private static boolean checkIncluded() {

	int i, k, l, m, n;
	int currentPnt1, currentPnt2;
	int nextPnt1, nextPnt2;
	int pntNbr;

	Poly removedPoly;
	double xMinVal;
	int xMinIndex = 0;
	
	boolean trouve = false;
	boolean ret = false;

	for (i = polyNbr - 1; i >= 0 && !trouve; i--){

	    pntNbr = polyBuffer[i].pointNbr;
	    
	    // pour �tre sur de partir de l'exterieur 
	    currentPnt1 = polyBuffer[i].firstPoint;
	    xMinVal = xBuf[currentPnt1];
	    xMinIndex = currentPnt1;
	    for (m = pntNbr; m > 0; m--){
		if ( xBuf[currentPnt1] < xMinVal ){
		    xMinVal = xBuf[currentPnt1];
		    xMinIndex = currentPnt1;
		}
		currentPnt1 = nextPoint[currentPnt1];
	    }
	    currentPnt1 = xMinIndex;

	    for (k = 0; k < pntNbr - 2 && !trouve; k++) {

		nextPnt1 = nextPoint[currentPnt1];
		currentPnt2 = nextPoint[nextPnt1];

		for (l = k + 2; l < pntNbr && !trouve; l++) {

		    nextPnt2 = nextPoint[currentPnt2];

		    if ( pointBuffer.distSqr(currentPnt1, nextPnt2) < SEUIL_DIST &&
			 pointBuffer.distSqr(nextPnt1, currentPnt2) < SEUIL_DIST ) {
			
			// s�pare l'enchainement en 2 (2 points sont d�tach�s)
			nextPoint[currentPnt1] = nextPoint[nextPnt2];
			nextPoint[currentPnt2] = nextPoint[nextPnt1];
			
			// enl�ve le poly 
			removedPoly = polyBuffer[i];
			for (n = i; n < polyNbr - 1; n++) {
			    polyBuffer[n] = polyBuffer[n + 1];
			}			
			polyNbr--;
			
			// cherche la premi�re place apr�s les poly 'pleins'
			for (m = 0; polyBuffer[m].type == CalcOutlinePolygon.BACK && m < polyNbr; m++);
			
//  			printf("inclusion trouvee\n"); 
			
			// d�cale les poly suivants pour liberer 2 places
			for (n = polyNbr + 1; n > m + 1; n--) {
			    polyBuffer[n] = polyBuffer[n - 2];
			}
			
			// init du 1er nouveau poly
			removedPoly.pointNbr -= l - k + 1;
			removedPoly.firstPoint = currentPnt1;
			if (removedPoly.type != CalcOutlinePolygon.ON) {
			    removedPoly.type = CalcOutlinePolygon.BACK;
			} else {
			    removedPoly.type = CalcOutlinePolygon.ON;
			}
			polyBuffer[m] = removedPoly;
			
			// init du deuxi�me
			polyBuffer[m + 1] = new Poly(currentPnt2, l - k - 1, CalcOutlinePolygon.ON);
			
			polyNbr += 2;
			
			trouve = ret = true;
			
		    }

		    currentPnt2 = nextPnt2;
		}

		currentPnt1 = nextPnt1;
	    }
	}
	
	return ret;
    }  
    


//      /**
//       * Place dans le segment le point et son successeur.
//       */

//      private static void fillSeg(int pnt) {
//  	xSeg[0] = xBuf[pnt];
//  	ySeg[0] = yBuf[pnt];
//  	xSeg[1] = xBuf[nextPoint[pnt]];
//  	ySeg[1] = yBuf[nextPoint[pnt]];
//      }


    /**
     * Structure correspondant � un polygone contenu dans le buffer.
     * Pointe sur des points dans le buffer.
     */

    static class Poly {
	
	int firstPoint;  // premier point ('pointeur' sur le buffer)
	int pointNbr;    // nb. de points (non compris celui de fermeture)
	int type;        // type de poly ()

	Poly( int fp, int pn) {
	    this(fp, pn, CalcOutlinePolygon.NORMAL);
	}

	Poly( int fp, int pn, int ty) {
	    firstPoint = fp;
	    pointNbr = pn;
	    type = ty;
	}
    }
}
