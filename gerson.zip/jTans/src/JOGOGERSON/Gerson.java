package JOGOGERSON;

import net.phbwt.jtans.jTansApplication;

public class Gerson {
public static boolean markin=false;
	public static void main(String[] args) {
		jTansApplication.main(null);
		if(markin)
		System.out.println("DESAFIO COMPLETO");
	}

}
